export class User{

    public UserType:string = "";
    public Email:string = "";
    public ReEnterPassword:string = "";
    public FName:string = "";

}