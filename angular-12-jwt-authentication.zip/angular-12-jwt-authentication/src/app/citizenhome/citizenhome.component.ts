import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizenhome',
  templateUrl: './citizenhome.component.html',
  styleUrls: ['./citizenhome.component.css']
})
export class CitizenhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
